﻿namespace Cliente_Mtis_Facturacion_Grupo7
{
    partial class ucEstadisticas
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            totalReportesEmitidosLabel = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            totalFacturasEmitidasLabel = new Label();
            totalFacturasValidasLabel = new Label();
            totalFacturasSubsanadasLabel = new Label();
            totalFacturasAnuladasLabel = new Label();
            totalFacturasInvalidasLabel = new Label();
            label3 = new Label();
            totalTodasFacturasValidasLabel = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold | FontStyle.Underline);
            label1.ForeColor = Color.FromArgb(128, 128, 255);
            label1.Location = new Point(666, 42);
            label1.Name = "label1";
            label1.Size = new Size(654, 46);
            label1.TabIndex = 0;
            label1.Text = "Estadísticas globales de este último mes";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label2.Location = new Point(532, 116);
            label2.Name = "label2";
            label2.Size = new Size(483, 30);
            label2.TabIndex = 3;
            label2.Text = "Nº total de reportes de estadísticas emitidos:";
            // 
            // totalReportesEmitidosLabel
            // 
            totalReportesEmitidosLabel.AutoSize = true;
            totalReportesEmitidosLabel.Font = new Font("Segoe UI", 13F);
            totalReportesEmitidosLabel.Location = new Point(1118, 116);
            totalReportesEmitidosLabel.Name = "totalReportesEmitidosLabel";
            totalReportesEmitidosLabel.Size = new Size(142, 30);
            totalReportesEmitidosLabel.TabIndex = 4;
            totalReportesEmitidosLabel.Text = "procesando...";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label5.Location = new Point(396, 246);
            label5.Name = "label5";
            label5.Size = new Size(619, 30);
            label5.TabIndex = 6;
            label5.Text = "Nº total de facturas válidas (rectificadas y no rectificadas):";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label6.Location = new Point(556, 311);
            label6.Name = "label6";
            label6.Size = new Size(459, 30);
            label6.TabIndex = 7;
            label6.Text = "Nº total de facturas validas no rectificadas:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label7.Location = new Point(588, 376);
            label7.Name = "label7";
            label7.Size = new Size(427, 30);
            label7.TabIndex = 8;
            label7.Text = "Nº total de facturas validas rectificadas:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label8.Location = new Point(694, 441);
            label8.Name = "label8";
            label8.Size = new Size(321, 30);
            label8.TabIndex = 9;
            label8.Text = "Nº total de facturas anuladas:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label9.Location = new Point(695, 506);
            label9.Name = "label9";
            label9.Size = new Size(320, 30);
            label9.TabIndex = 10;
            label9.Text = "Nº total de facturas invalidas:";
            // 
            // totalFacturasEmitidasLabel
            // 
            totalFacturasEmitidasLabel.AutoSize = true;
            totalFacturasEmitidasLabel.Font = new Font("Segoe UI", 13F);
            totalFacturasEmitidasLabel.Location = new Point(1118, 181);
            totalFacturasEmitidasLabel.Name = "totalFacturasEmitidasLabel";
            totalFacturasEmitidasLabel.Size = new Size(142, 30);
            totalFacturasEmitidasLabel.TabIndex = 11;
            totalFacturasEmitidasLabel.Text = "procesando...";
            // 
            // totalFacturasValidasLabel
            // 
            totalFacturasValidasLabel.AutoSize = true;
            totalFacturasValidasLabel.Font = new Font("Segoe UI", 13F);
            totalFacturasValidasLabel.Location = new Point(1118, 311);
            totalFacturasValidasLabel.Name = "totalFacturasValidasLabel";
            totalFacturasValidasLabel.Size = new Size(142, 30);
            totalFacturasValidasLabel.TabIndex = 13;
            totalFacturasValidasLabel.Text = "procesando...";
            // 
            // totalFacturasSubsanadasLabel
            // 
            totalFacturasSubsanadasLabel.AutoSize = true;
            totalFacturasSubsanadasLabel.Font = new Font("Segoe UI", 13F);
            totalFacturasSubsanadasLabel.Location = new Point(1118, 376);
            totalFacturasSubsanadasLabel.Name = "totalFacturasSubsanadasLabel";
            totalFacturasSubsanadasLabel.Size = new Size(142, 30);
            totalFacturasSubsanadasLabel.TabIndex = 14;
            totalFacturasSubsanadasLabel.Text = "procesando...";
            // 
            // totalFacturasAnuladasLabel
            // 
            totalFacturasAnuladasLabel.AutoSize = true;
            totalFacturasAnuladasLabel.Font = new Font("Segoe UI", 13F);
            totalFacturasAnuladasLabel.Location = new Point(1118, 441);
            totalFacturasAnuladasLabel.Name = "totalFacturasAnuladasLabel";
            totalFacturasAnuladasLabel.Size = new Size(142, 30);
            totalFacturasAnuladasLabel.TabIndex = 15;
            totalFacturasAnuladasLabel.Text = "procesando...";
            // 
            // totalFacturasInvalidasLabel
            // 
            totalFacturasInvalidasLabel.AutoSize = true;
            totalFacturasInvalidasLabel.Font = new Font("Segoe UI", 13F);
            totalFacturasInvalidasLabel.Location = new Point(1118, 506);
            totalFacturasInvalidasLabel.Name = "totalFacturasInvalidasLabel";
            totalFacturasInvalidasLabel.Size = new Size(142, 30);
            totalFacturasInvalidasLabel.TabIndex = 16;
            totalFacturasInvalidasLabel.Text = "procesando...";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label3.Location = new Point(697, 181);
            label3.Name = "label3";
            label3.Size = new Size(318, 30);
            label3.TabIndex = 17;
            label3.Text = "Nº total de facturas emitidas:";
            // 
            // totalTodasFacturasValidasLabel
            // 
            totalTodasFacturasValidasLabel.AutoSize = true;
            totalTodasFacturasValidasLabel.Font = new Font("Segoe UI", 13F);
            totalTodasFacturasValidasLabel.Location = new Point(1118, 246);
            totalTodasFacturasValidasLabel.Name = "totalTodasFacturasValidasLabel";
            totalTodasFacturasValidasLabel.Size = new Size(142, 30);
            totalTodasFacturasValidasLabel.TabIndex = 18;
            totalTodasFacturasValidasLabel.Text = "procesando...";
            // 
            // ucEstadisticas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(totalTodasFacturasValidasLabel);
            Controls.Add(label3);
            Controls.Add(totalFacturasInvalidasLabel);
            Controls.Add(totalFacturasAnuladasLabel);
            Controls.Add(totalFacturasSubsanadasLabel);
            Controls.Add(totalFacturasValidasLabel);
            Controls.Add(totalFacturasEmitidasLabel);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(totalReportesEmitidosLabel);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ucEstadisticas";
            Size = new Size(1902, 1002);
            Load += ucEstadisticas_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label totalReportesEmitidosLabel;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label totalFacturasEmitidasLabel;
        private Label totalFacturasValidasLabel;
        private Label totalFacturasSubsanadasLabel;
        private Label totalFacturasAnuladasLabel;
        private Label totalFacturasInvalidasLabel;
        private Label label3;
        private Label totalTodasFacturasValidasLabel;
    }
}
