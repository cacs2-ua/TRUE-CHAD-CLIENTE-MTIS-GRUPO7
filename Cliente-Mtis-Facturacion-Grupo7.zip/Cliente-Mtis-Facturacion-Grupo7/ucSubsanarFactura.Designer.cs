﻿namespace Cliente_Mtis_Facturacion_Grupo7
{
    partial class ucSubsanarFactura
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            subsanarButton = new Button();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            fechaFinalFacturacionTextBox = new TextBox();
            fechaInicioFacturacionTextBox = new TextBox();
            monedaTextBox = new TextBox();
            ivaTextBox = new TextBox();
            baseImponibleTextBox = new TextBox();
            numeroFacturaTextBox = new TextBox();
            label16 = new Label();
            codigoPostalEmpresaTextbox = new TextBox();
            label17 = new Label();
            direccionCompletaFacturacionTextBox = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            localidadEmpresaTextBox = new TextBox();
            provinciaEmpresaTextBox = new TextBox();
            paisEmpresaTextBox = new TextBox();
            ibanEmpresaTextBox = new TextBox();
            identificadorEmpleadorTextBox = new TextBox();
            identificadorFiscalEmpresaTextBox = new TextBox();
            label4 = new Label();
            emailEmpresaTextBox = new TextBox();
            label2 = new Label();
            nombreEmpresaTextBox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // subsanarButton
            // 
            subsanarButton.BackColor = SystemColors.GradientActiveCaption;
            subsanarButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            subsanarButton.Location = new Point(920, 508);
            subsanarButton.Name = "subsanarButton";
            subsanarButton.Size = new Size(187, 51);
            subsanarButton.TabIndex = 70;
            subsanarButton.Text = "Subsanar";
            subsanarButton.UseVisualStyleBackColor = false;
            subsanarButton.Click += subsanarButton_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(963, 439);
            label10.Name = "label10";
            label10.Size = new Size(195, 20);
            label10.TabIndex = 69;
            label10.Text = "Fecha final de la facturación";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(956, 392);
            label11.Name = "label11";
            label11.Size = new Size(202, 20);
            label11.TabIndex = 68;
            label11.Text = "Fecha inicio de la facturación";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(1094, 345);
            label12.Name = "label12";
            label12.Size = new Size(64, 20);
            label12.TabIndex = 67;
            label12.Text = "Moneda";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(1127, 298);
            label13.Name = "label13";
            label13.Size = new Size(31, 20);
            label13.TabIndex = 66;
            label13.Text = "IVA";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(1046, 251);
            label14.Name = "label14";
            label14.Size = new Size(112, 20);
            label14.TabIndex = 65;
            label14.Text = "Base imponible";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(1024, 204);
            label15.Name = "label15";
            label15.Size = new Size(134, 20);
            label15.TabIndex = 64;
            label15.Text = "Número de factura";
            // 
            // fechaFinalFacturacionTextBox
            // 
            fechaFinalFacturacionTextBox.Location = new Point(1176, 436);
            fechaFinalFacturacionTextBox.Name = "fechaFinalFacturacionTextBox";
            fechaFinalFacturacionTextBox.Size = new Size(327, 27);
            fechaFinalFacturacionTextBox.TabIndex = 63;
            // 
            // fechaInicioFacturacionTextBox
            // 
            fechaInicioFacturacionTextBox.Location = new Point(1176, 389);
            fechaInicioFacturacionTextBox.Name = "fechaInicioFacturacionTextBox";
            fechaInicioFacturacionTextBox.Size = new Size(327, 27);
            fechaInicioFacturacionTextBox.TabIndex = 62;
            // 
            // monedaTextBox
            // 
            monedaTextBox.Location = new Point(1176, 342);
            monedaTextBox.Name = "monedaTextBox";
            monedaTextBox.Size = new Size(327, 27);
            monedaTextBox.TabIndex = 61;
            // 
            // ivaTextBox
            // 
            ivaTextBox.Location = new Point(1176, 295);
            ivaTextBox.Name = "ivaTextBox";
            ivaTextBox.Size = new Size(327, 27);
            ivaTextBox.TabIndex = 60;
            // 
            // baseImponibleTextBox
            // 
            baseImponibleTextBox.Location = new Point(1176, 248);
            baseImponibleTextBox.Name = "baseImponibleTextBox";
            baseImponibleTextBox.Size = new Size(327, 27);
            baseImponibleTextBox.TabIndex = 59;
            // 
            // numeroFacturaTextBox
            // 
            numeroFacturaTextBox.Location = new Point(1176, 201);
            numeroFacturaTextBox.Name = "numeroFacturaTextBox";
            numeroFacturaTextBox.Size = new Size(327, 27);
            numeroFacturaTextBox.TabIndex = 58;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(957, 157);
            label16.Name = "label16";
            label16.Size = new Size(201, 20);
            label16.TabIndex = 57;
            label16.Text = "Código postal de la empresa";
            // 
            // codigoPostalEmpresaTextbox
            // 
            codigoPostalEmpresaTextbox.Location = new Point(1176, 154);
            codigoPostalEmpresaTextbox.Name = "codigoPostalEmpresaTextbox";
            codigoPostalEmpresaTextbox.Size = new Size(327, 27);
            codigoPostalEmpresaTextbox.TabIndex = 56;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(920, 110);
            label17.Name = "label17";
            label17.Size = new Size(238, 20);
            label17.TabIndex = 55;
            label17.Text = "Dirección completa de facturación";
            // 
            // direccionCompletaFacturacionTextBox
            // 
            direccionCompletaFacturacionTextBox.Location = new Point(1176, 107);
            direccionCompletaFacturacionTextBox.Name = "direccionCompletaFacturacionTextBox";
            direccionCompletaFacturacionTextBox.Size = new Size(327, 27);
            direccionCompletaFacturacionTextBox.TabIndex = 54;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(332, 439);
            label9.Name = "label9";
            label9.Size = new Size(172, 20);
            label9.TabIndex = 53;
            label9.Text = "Localidad de la empresa";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(337, 392);
            label8.Name = "label8";
            label8.Size = new Size(167, 20);
            label8.TabIndex = 52;
            label8.Text = "Provincia de la empresa";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(372, 345);
            label7.Name = "label7";
            label7.Size = new Size(132, 20);
            label7.TabIndex = 51;
            label7.Text = "País de la empresa";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(363, 298);
            label6.Name = "label6";
            label6.Size = new Size(141, 20);
            label6.TabIndex = 50;
            label6.Text = "IBAN de la empresa";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(308, 251);
            label5.Name = "label5";
            label5.Size = new Size(196, 20);
            label5.TabIndex = 49;
            label5.Text = "Identificador del empleador";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(274, 204);
            label3.Name = "label3";
            label3.Size = new Size(230, 20);
            label3.TabIndex = 48;
            label3.Text = "Identificador fiscal de la empresa";
            // 
            // localidadEmpresaTextBox
            // 
            localidadEmpresaTextBox.Location = new Point(522, 436);
            localidadEmpresaTextBox.Name = "localidadEmpresaTextBox";
            localidadEmpresaTextBox.Size = new Size(327, 27);
            localidadEmpresaTextBox.TabIndex = 47;
            // 
            // provinciaEmpresaTextBox
            // 
            provinciaEmpresaTextBox.Location = new Point(522, 389);
            provinciaEmpresaTextBox.Name = "provinciaEmpresaTextBox";
            provinciaEmpresaTextBox.Size = new Size(327, 27);
            provinciaEmpresaTextBox.TabIndex = 46;
            // 
            // paisEmpresaTextBox
            // 
            paisEmpresaTextBox.Location = new Point(522, 342);
            paisEmpresaTextBox.Name = "paisEmpresaTextBox";
            paisEmpresaTextBox.Size = new Size(327, 27);
            paisEmpresaTextBox.TabIndex = 45;
            // 
            // ibanEmpresaTextBox
            // 
            ibanEmpresaTextBox.Location = new Point(522, 295);
            ibanEmpresaTextBox.Name = "ibanEmpresaTextBox";
            ibanEmpresaTextBox.Size = new Size(327, 27);
            ibanEmpresaTextBox.TabIndex = 44;
            // 
            // identificadorEmpleadorTextBox
            // 
            identificadorEmpleadorTextBox.Location = new Point(522, 248);
            identificadorEmpleadorTextBox.Name = "identificadorEmpleadorTextBox";
            identificadorEmpleadorTextBox.Size = new Size(327, 27);
            identificadorEmpleadorTextBox.TabIndex = 43;
            // 
            // identificadorFiscalEmpresaTextBox
            // 
            identificadorFiscalEmpresaTextBox.Location = new Point(522, 201);
            identificadorFiscalEmpresaTextBox.Name = "identificadorFiscalEmpresaTextBox";
            identificadorFiscalEmpresaTextBox.Size = new Size(327, 27);
            identificadorFiscalEmpresaTextBox.TabIndex = 42;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(360, 157);
            label4.Name = "label4";
            label4.Size = new Size(144, 20);
            label4.TabIndex = 41;
            label4.Text = "Email de la empresa";
            // 
            // emailEmpresaTextBox
            // 
            emailEmpresaTextBox.Location = new Point(522, 154);
            emailEmpresaTextBox.Name = "emailEmpresaTextBox";
            emailEmpresaTextBox.Size = new Size(327, 27);
            emailEmpresaTextBox.TabIndex = 40;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(342, 110);
            label2.Name = "label2";
            label2.Size = new Size(162, 20);
            label2.TabIndex = 39;
            label2.Text = "Nombre de la empresa";
            // 
            // nombreEmpresaTextBox
            // 
            nombreEmpresaTextBox.Location = new Point(522, 107);
            nombreEmpresaTextBox.Name = "nombreEmpresaTextBox";
            nombreEmpresaTextBox.Size = new Size(327, 27);
            nombreEmpresaTextBox.TabIndex = 38;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold | FontStyle.Underline);
            label1.ForeColor = Color.FromArgb(128, 128, 255);
            label1.Location = new Point(832, 42);
            label1.Name = "label1";
            label1.Size = new Size(358, 46);
            label1.TabIndex = 37;
            label1.Text = "Subsanar una factura";
            // 
            // ucSubsanarFactura
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(subsanarButton);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(fechaFinalFacturacionTextBox);
            Controls.Add(fechaInicioFacturacionTextBox);
            Controls.Add(monedaTextBox);
            Controls.Add(ivaTextBox);
            Controls.Add(baseImponibleTextBox);
            Controls.Add(numeroFacturaTextBox);
            Controls.Add(label16);
            Controls.Add(codigoPostalEmpresaTextbox);
            Controls.Add(label17);
            Controls.Add(direccionCompletaFacturacionTextBox);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(localidadEmpresaTextBox);
            Controls.Add(provinciaEmpresaTextBox);
            Controls.Add(paisEmpresaTextBox);
            Controls.Add(ibanEmpresaTextBox);
            Controls.Add(identificadorEmpleadorTextBox);
            Controls.Add(identificadorFiscalEmpresaTextBox);
            Controls.Add(label4);
            Controls.Add(emailEmpresaTextBox);
            Controls.Add(label2);
            Controls.Add(nombreEmpresaTextBox);
            Controls.Add(label1);
            Name = "ucSubsanarFactura";
            Size = new Size(1902, 1002);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button subsanarButton;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox fechaFinalFacturacionTextBox;
        private TextBox fechaInicioFacturacionTextBox;
        private TextBox monedaTextBox;
        private TextBox ivaTextBox;
        private TextBox baseImponibleTextBox;
        private TextBox numeroFacturaTextBox;
        private Label label16;
        private TextBox codigoPostalEmpresaTextbox;
        private Label label17;
        private TextBox direccionCompletaFacturacionTextBox;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private TextBox localidadEmpresaTextBox;
        private TextBox provinciaEmpresaTextBox;
        private TextBox paisEmpresaTextBox;
        private TextBox ibanEmpresaTextBox;
        private TextBox identificadorEmpleadorTextBox;
        private TextBox identificadorFiscalEmpresaTextBox;
        private Label label4;
        private TextBox emailEmpresaTextBox;
        private Label label2;
        private TextBox nombreEmpresaTextBox;
        private Label label1;
    }
}
