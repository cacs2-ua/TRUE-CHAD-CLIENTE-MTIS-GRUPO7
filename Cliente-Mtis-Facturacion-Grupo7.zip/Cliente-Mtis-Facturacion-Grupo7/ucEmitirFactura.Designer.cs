﻿namespace Cliente_Mtis_Facturacion_Grupo7
{
    partial class ucEmitirFactura
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            nombreEmpresaTextBox = new TextBox();
            label2 = new Label();
            label4 = new Label();
            emailEmpresaTextBox = new TextBox();
            identificadorFiscalEmpresaTextBox = new TextBox();
            identificadorEmpleadorTextBox = new TextBox();
            ibanEmpresaTextBox = new TextBox();
            paisEmpresaTextBox = new TextBox();
            provinciaEmpresaTextBox = new TextBox();
            localidadEmpresaTextBox = new TextBox();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            fechaFinalFacturacionTextBox = new TextBox();
            fechaInicioFacturacionTextBox = new TextBox();
            monedaTextBox = new TextBox();
            ivaTextBox = new TextBox();
            baseImponibleTextBox = new TextBox();
            numeroFacturaTextBox = new TextBox();
            label16 = new Label();
            codigoPostalEmpresaTextbox = new TextBox();
            label17 = new Label();
            direccionCompletaFacturacionTextBox = new TextBox();
            emitirButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold | FontStyle.Underline);
            label1.ForeColor = Color.FromArgb(128, 128, 255);
            label1.Location = new Point(780, 42);
            label1.Name = "label1";
            label1.Size = new Size(411, 46);
            label1.TabIndex = 0;
            label1.Text = "Emitir una nueva factura";
            // 
            // nombreEmpresaTextBox
            // 
            nombreEmpresaTextBox.Location = new Point(497, 112);
            nombreEmpresaTextBox.Name = "nombreEmpresaTextBox";
            nombreEmpresaTextBox.Size = new Size(327, 27);
            nombreEmpresaTextBox.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(317, 115);
            label2.Name = "label2";
            label2.Size = new Size(162, 20);
            label2.TabIndex = 2;
            label2.Text = "Nombre de la empresa";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(335, 162);
            label4.Name = "label4";
            label4.Size = new Size(144, 20);
            label4.TabIndex = 6;
            label4.Text = "Email de la empresa";
            // 
            // emailEmpresaTextBox
            // 
            emailEmpresaTextBox.Location = new Point(497, 159);
            emailEmpresaTextBox.Name = "emailEmpresaTextBox";
            emailEmpresaTextBox.Size = new Size(327, 27);
            emailEmpresaTextBox.TabIndex = 5;
            // 
            // identificadorFiscalEmpresaTextBox
            // 
            identificadorFiscalEmpresaTextBox.Location = new Point(497, 206);
            identificadorFiscalEmpresaTextBox.Name = "identificadorFiscalEmpresaTextBox";
            identificadorFiscalEmpresaTextBox.Size = new Size(327, 27);
            identificadorFiscalEmpresaTextBox.TabIndex = 7;
            // 
            // identificadorEmpleadorTextBox
            // 
            identificadorEmpleadorTextBox.Location = new Point(497, 253);
            identificadorEmpleadorTextBox.Name = "identificadorEmpleadorTextBox";
            identificadorEmpleadorTextBox.Size = new Size(327, 27);
            identificadorEmpleadorTextBox.TabIndex = 8;
            // 
            // ibanEmpresaTextBox
            // 
            ibanEmpresaTextBox.Location = new Point(497, 300);
            ibanEmpresaTextBox.Name = "ibanEmpresaTextBox";
            ibanEmpresaTextBox.Size = new Size(327, 27);
            ibanEmpresaTextBox.TabIndex = 9;
            // 
            // paisEmpresaTextBox
            // 
            paisEmpresaTextBox.Location = new Point(497, 347);
            paisEmpresaTextBox.Name = "paisEmpresaTextBox";
            paisEmpresaTextBox.Size = new Size(327, 27);
            paisEmpresaTextBox.TabIndex = 11;
            // 
            // provinciaEmpresaTextBox
            // 
            provinciaEmpresaTextBox.Location = new Point(497, 394);
            provinciaEmpresaTextBox.Name = "provinciaEmpresaTextBox";
            provinciaEmpresaTextBox.Size = new Size(327, 27);
            provinciaEmpresaTextBox.TabIndex = 12;
            // 
            // localidadEmpresaTextBox
            // 
            localidadEmpresaTextBox.Location = new Point(497, 441);
            localidadEmpresaTextBox.Name = "localidadEmpresaTextBox";
            localidadEmpresaTextBox.Size = new Size(327, 27);
            localidadEmpresaTextBox.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(249, 209);
            label3.Name = "label3";
            label3.Size = new Size(230, 20);
            label3.TabIndex = 14;
            label3.Text = "Identificador fiscal de la empresa";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(283, 256);
            label5.Name = "label5";
            label5.Size = new Size(196, 20);
            label5.TabIndex = 15;
            label5.Text = "Identificador del empleador";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(338, 303);
            label6.Name = "label6";
            label6.Size = new Size(141, 20);
            label6.TabIndex = 16;
            label6.Text = "IBAN de la empresa";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(347, 350);
            label7.Name = "label7";
            label7.Size = new Size(132, 20);
            label7.TabIndex = 17;
            label7.Text = "País de la empresa";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(312, 397);
            label8.Name = "label8";
            label8.Size = new Size(167, 20);
            label8.TabIndex = 18;
            label8.Text = "Provincia de la empresa";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(307, 444);
            label9.Name = "label9";
            label9.Size = new Size(172, 20);
            label9.TabIndex = 19;
            label9.Text = "Localidad de la empresa";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(938, 444);
            label10.Name = "label10";
            label10.Size = new Size(195, 20);
            label10.TabIndex = 35;
            label10.Text = "Fecha final de la facturación";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(931, 397);
            label11.Name = "label11";
            label11.Size = new Size(202, 20);
            label11.TabIndex = 34;
            label11.Text = "Fecha inicio de la facturación";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(1069, 350);
            label12.Name = "label12";
            label12.Size = new Size(64, 20);
            label12.TabIndex = 33;
            label12.Text = "Moneda";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(1102, 303);
            label13.Name = "label13";
            label13.Size = new Size(31, 20);
            label13.TabIndex = 32;
            label13.Text = "IVA";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(1021, 256);
            label14.Name = "label14";
            label14.Size = new Size(112, 20);
            label14.TabIndex = 31;
            label14.Text = "Base imponible";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(999, 209);
            label15.Name = "label15";
            label15.Size = new Size(134, 20);
            label15.TabIndex = 30;
            label15.Text = "Número de factura";
            // 
            // fechaFinalFacturacionTextBox
            // 
            fechaFinalFacturacionTextBox.Location = new Point(1151, 441);
            fechaFinalFacturacionTextBox.Name = "fechaFinalFacturacionTextBox";
            fechaFinalFacturacionTextBox.Size = new Size(327, 27);
            fechaFinalFacturacionTextBox.TabIndex = 29;
            // 
            // fechaInicioFacturacionTextBox
            // 
            fechaInicioFacturacionTextBox.Location = new Point(1151, 394);
            fechaInicioFacturacionTextBox.Name = "fechaInicioFacturacionTextBox";
            fechaInicioFacturacionTextBox.Size = new Size(327, 27);
            fechaInicioFacturacionTextBox.TabIndex = 28;
            // 
            // monedaTextBox
            // 
            monedaTextBox.Location = new Point(1151, 347);
            monedaTextBox.Name = "monedaTextBox";
            monedaTextBox.Size = new Size(327, 27);
            monedaTextBox.TabIndex = 27;
            // 
            // ivaTextBox
            // 
            ivaTextBox.Location = new Point(1151, 300);
            ivaTextBox.Name = "ivaTextBox";
            ivaTextBox.Size = new Size(327, 27);
            ivaTextBox.TabIndex = 26;
            // 
            // baseImponibleTextBox
            // 
            baseImponibleTextBox.Location = new Point(1151, 253);
            baseImponibleTextBox.Name = "baseImponibleTextBox";
            baseImponibleTextBox.Size = new Size(327, 27);
            baseImponibleTextBox.TabIndex = 25;
            // 
            // numeroFacturaTextBox
            // 
            numeroFacturaTextBox.Location = new Point(1151, 206);
            numeroFacturaTextBox.Name = "numeroFacturaTextBox";
            numeroFacturaTextBox.Size = new Size(327, 27);
            numeroFacturaTextBox.TabIndex = 24;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(932, 162);
            label16.Name = "label16";
            label16.Size = new Size(201, 20);
            label16.TabIndex = 23;
            label16.Text = "Código postal de la empresa";
            // 
            // codigoPostalEmpresaTextbox
            // 
            codigoPostalEmpresaTextbox.Location = new Point(1151, 159);
            codigoPostalEmpresaTextbox.Name = "codigoPostalEmpresaTextbox";
            codigoPostalEmpresaTextbox.Size = new Size(327, 27);
            codigoPostalEmpresaTextbox.TabIndex = 22;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(895, 115);
            label17.Name = "label17";
            label17.Size = new Size(238, 20);
            label17.TabIndex = 21;
            label17.Text = "Dirección completa de facturación";
            // 
            // direccionCompletaFacturacionTextBox
            // 
            direccionCompletaFacturacionTextBox.Location = new Point(1151, 112);
            direccionCompletaFacturacionTextBox.Name = "direccionCompletaFacturacionTextBox";
            direccionCompletaFacturacionTextBox.Size = new Size(327, 27);
            direccionCompletaFacturacionTextBox.TabIndex = 20;
            // 
            // emitirButton
            // 
            emitirButton.BackColor = SystemColors.GradientActiveCaption;
            emitirButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            emitirButton.Location = new Point(895, 513);
            emitirButton.Name = "emitirButton";
            emitirButton.Size = new Size(187, 51);
            emitirButton.TabIndex = 36;
            emitirButton.Text = "Emitir";
            emitirButton.UseVisualStyleBackColor = false;
            emitirButton.Click += emitirButton_Click;
            // 
            // ucEmitirFactura
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(emitirButton);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(fechaFinalFacturacionTextBox);
            Controls.Add(fechaInicioFacturacionTextBox);
            Controls.Add(monedaTextBox);
            Controls.Add(ivaTextBox);
            Controls.Add(baseImponibleTextBox);
            Controls.Add(numeroFacturaTextBox);
            Controls.Add(label16);
            Controls.Add(codigoPostalEmpresaTextbox);
            Controls.Add(label17);
            Controls.Add(direccionCompletaFacturacionTextBox);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(localidadEmpresaTextBox);
            Controls.Add(provinciaEmpresaTextBox);
            Controls.Add(paisEmpresaTextBox);
            Controls.Add(ibanEmpresaTextBox);
            Controls.Add(identificadorEmpleadorTextBox);
            Controls.Add(identificadorFiscalEmpresaTextBox);
            Controls.Add(label4);
            Controls.Add(emailEmpresaTextBox);
            Controls.Add(label2);
            Controls.Add(nombreEmpresaTextBox);
            Controls.Add(label1);
            Name = "ucEmitirFactura";
            Size = new Size(1902, 1002);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox nombreEmpresaTextBox;
        private Label label2;
        private Label label4;
        private TextBox emailEmpresaTextBox;
        private TextBox identificadorFiscalEmpresaTextBox;
        private TextBox identificadorEmpleadorTextBox;
        private TextBox ibanEmpresaTextBox;
        private TextBox paisEmpresaTextBox;
        private TextBox provinciaEmpresaTextBox;
        private TextBox localidadEmpresaTextBox;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox fechaFinalFacturacionTextBox;
        private TextBox fechaInicioFacturacionTextBox;
        private TextBox monedaTextBox;
        private TextBox ivaTextBox;
        private TextBox baseImponibleTextBox;
        private TextBox numeroFacturaTextBox;
        private Label label16;
        private TextBox codigoPostalEmpresaTextbox;
        private Label label17;
        private TextBox direccionCompletaFacturacionTextBox;
        private Button emitirButton;
    }
}
